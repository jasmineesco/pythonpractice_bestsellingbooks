I am currently building my skills & portfolio. This project is from Grace Peters in Codedex, "Analyze Best Selling Amazon Books with Pandas"! 

Here is the link for their project: https://www.codedex.io/projects/analyze-spreadsheet-data-with-pandas-chatgpt
