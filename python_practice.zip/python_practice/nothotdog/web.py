#web.py

from flask import Flask, render_template, request, jsonify
import requests
import json
import os
from dotenv import load_dotenv

load_dotenv() 
# loads environment variables from a .env (contains API keys or othere sensitive infos na no need ihard code) 
# file into d Python environment
# .env yung file na ginawa na andon lahat ng sensitive infos ni hugging face like the url & key

API_URL = os.getenv("HUGGING_FACE_API_URL")
# kinukuha url ni hugging face that's dictated sa .env file
# stinore sa variable para magamit later on

headers = {'Authorization': f'Bearer {os.getenv("HUGGING_FACE_API_KEY")}'}
# 

app = Flask(__name__)

def query(data):
    response = requests.request('POST', API_URL, headers=headers, data=data)
    return json.loads(response.content.decode('utf-8'))